usethis::create_from_github("yourusername/RNAseq_Workshop")
renv::restore()



renv::restore()



# install.packages('Seurat')
# install.packages("BiocManager")
# BiocManager::install("DESeq2")
# 
# 
# renv::snapshot()
